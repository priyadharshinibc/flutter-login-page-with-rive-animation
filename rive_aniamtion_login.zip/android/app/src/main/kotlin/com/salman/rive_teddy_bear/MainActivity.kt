package com.salman.rive_teddy_bear

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

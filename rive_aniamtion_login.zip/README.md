# rive_teddy_bear

A project to demostrate about the rive annimations in Flutter

You can also watch the complete video tutorial on rive animation implementation with interactive login UI and teddy animation.

- [Complete Video Tutorial - https://youtu.be/kNL5Eb451ns](https://youtu.be/kNL5Eb451ns)

![Video Thumbnail](https://img.youtube.com/vi/kNL5Eb451ns/0.jpg)

